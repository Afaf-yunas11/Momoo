from langchain_google_genai import ChatGoogleGenerativeAI

from app.config import settings
from app.exceptions import MissingModelConfigurationError


def get_llm() -> ChatGoogleGenerativeAI:
    api_key = settings.effective_api_key
    if not api_key:
        raise MissingModelConfigurationError(
            "Gemini API key is not configured. Set GEMINI_API_KEY or GOOGLE_API_KEY."
        )

    return ChatGoogleGenerativeAI(
        model=settings.gemini_model,
        google_api_key=api_key,
        temperature=0.2,
    )
