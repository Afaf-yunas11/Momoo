class MissingModelConfigurationError(RuntimeError):
    pass
