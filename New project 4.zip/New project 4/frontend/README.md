# mOOMOO Frontend Placeholder

This folder is intentionally lightweight for now.

Planned frontend stack from the requirements doc:

- React 18
- TypeScript
- Vite
- React Router
- Zustand
- TanStack Query
- Tailwind CSS
- shadcn/ui

Suggested next step later:

```powershell
npm create vite@latest frontend -- --template react-ts
```

For now, this folder exists so backend and frontend can evolve side by side in one repo.
