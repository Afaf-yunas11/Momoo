package com.moomoo.modules.reports;

import java.time.Instant;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class ReportService {

    private final ReportArchiveRepository reportArchiveRepository;

    public ReportService(ReportArchiveRepository reportArchiveRepository) {
        this.reportArchiveRepository = reportArchiveRepository;
    }

    public ReportArchive generate(ReportArchive request) {
        request.setGeneratedAt(Instant.now());
        if (request.getFilePath() == null) {
            request.setFilePath("/tmp/" + request.getReportType() + ".pdf");
        }
        return reportArchiveRepository.save(request);
    }

    public List<ReportArchive> findAll() {
        return reportArchiveRepository.findAll();
    }
}
