package com.moomoo.auth;

import com.moomoo.common.Role;
import java.time.Instant;

public record AuthResponse(
        String accessToken,
        String email,
        Role role,
        Instant accessTokenExpiresAt
) {
}
